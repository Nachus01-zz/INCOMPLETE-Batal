#ifndef Serial_H_
#define Serial _H_
#include "types.h"

#define BAUDRATE 9600

void Serial_Init();

void Serial_Write(u8);

#endif